This directory is populated during the release workflow.
The GitHub Pages build copies the root skills.json into docs/_data/skills.json.
