## Summary
- ...

## Changes
- ...

## How to test
- `python scripts/validate_skills.py`

## Notes / risk
- ...

