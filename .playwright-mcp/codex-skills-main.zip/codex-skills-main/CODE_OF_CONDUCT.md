# Code of Conduct

This project follows the Contributor Covenant Code of Conduct.

- Be respectful.
- Assume good intent.
- No harassment or hate speech.

Enforcement: maintainers may remove content or restrict participation for behavior that violates these expectations.

